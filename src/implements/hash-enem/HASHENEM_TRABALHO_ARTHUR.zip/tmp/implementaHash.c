#include "implementaLista.c"

 typedef struct hash{
        lista *l;
        int colisao;
    }hash;

    escola buscaLista(lista l, int key){
        escola a;
        a.id = -100;
        no* aux = l.primeiro;
    
    
    while(aux->prox != NULL){
        if(aux->escola.id == key){
        return aux->escola;
        }

        aux = aux->prox;
    }
        return a;
    }

    

    void slotsVazios(hash *tabela, int tamanhoHash){
        int i , vazios = 0;
        for(i=0;i<tamanhoHash;i++){
            if(tabela[i].l->qntLista == 0 ){
                vazios++;
            }
        }
        printf("Numero de slots vazios na Tabela Hash = %d \n", vazios);
    }

    void tamanhoMedio(hash *tabela, int tamanhoHash){
        int i , tam = 0 , medio = 0 ;
        for(i=0; i<tamanhoHash;i++){
            tam += tabela[i].l->qntLista;
        }
        medio = (int)(tam/tamanhoHash);
        printf("Tamanho medio das listas nos slots = %d\n", medio);
        }


    void imprimirTempo(clock_t t){
        printf("Tempo para inserir todos os dados = %.6lf ms\n", ((double)t)/((CLOCKS_PER_SEC/1000)));
    }

    void imprimeInfos(hash *tabela, int tamanhoHash, clock_t t,int colisao){
        slotsVazios(tabela , tamanhoHash);
        tamanhoMedio(tabela, tamanhoHash);
        printf("Numero total de colisoes = %d\n", colisao);        
        imprimirTempo(t);
        printf("\n");
    }
