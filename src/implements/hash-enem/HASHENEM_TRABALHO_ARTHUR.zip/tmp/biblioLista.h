#ifndef BIBLIOLIST_H   // guardas de cabeçalho, impedem inclusões cíclicas
#define BIBLIOLIST_H

//BIBLIOTECAS
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

    typedef struct escola {
        int id;
	    char estado[5];
	    char municipio[30];
	    char rede[10];
	    float media_ciencias_natureza;
	    float media_ciencias_humanas;
	    float media_linguagem;
	    float media_matematica;
	    float media_redacao;
    }escola;

    typedef struct no{
        struct no* prox;
        escola escola;
    }no;

    typedef struct lista{
        no* primeiro;
        no* ultimo;
        int qntLista;
    }lista;

    //FUNCOES DA ESCOLA
    void imprimirEscola(escola e);

    //FUNCOES DA LISTA.
    lista* criaLista();
    void insereLista(lista *l, escola e);
    int vaziaLista(lista l);
    void remover(lista *l, int chave);



#endif