#include "biblioLista.h"

lista* criaLista(){
    lista* l = (lista*)malloc(sizeof(lista));

    l->primeiro = (no*)malloc(sizeof(no));
    l->ultimo = l->primeiro;
    l->ultimo->prox = NULL;
    l->qntLista = 0;
    return l;
}

int vaziaLista(lista l){
    return (l.ultimo == l.primeiro);
}

void insereLista(lista *l, escola e){
    l->ultimo->prox = (no*)malloc(sizeof(no));
    l->ultimo->prox->prox = l->ultimo;
    l->ultimo = l->ultimo->prox;
    l->ultimo->prox = NULL;
    l->ultimo->escola = e;
    l->qntLista++;
}


void imprimirEscola(escola e){
    printf("\nID: %d\n", e.id);
    printf("Estado: %s\n", e.estado);
    printf("Municipio: %s\n",e.municipio);
    printf("Rede: %s\n",e.rede);
    printf("Media Natureza: %.2f\n", e.media_ciencias_natureza);
    printf("Media Humanas: %.2f\n", e.media_ciencias_humanas);
    printf("Media Linguagem: %.2f\n", e.media_linguagem);
    printf("Media Matematica: %.2f\n", e.media_matematica);
    printf("Media Redacao:  %.2f\n", e.media_redacao);
    printf("\n");
}


