   #include "implementaHash.c"

    int main(int argc, char **argv){
        //VARIAVEIS DA MAIN.
        int idProcurar = -1;
        int tamanhoHash = -1;
        int keyMod = -1;
        char arquivoIds[30];
        char arquivoBusca[30];
        int flagImprimir = -1;
        int flagDeIds = 0;
        FILE *arqIds;
        FILE *arqBusca;
        int linhasIds = 0;
        int linhasEscolas =0;
        char auxLinhas[100];
        char *token;
        char aux[120];
        const char separa[2] = ";"; 
        clock_t t;
        int colisao=0;
        int temp;
        int txtIds =0;
        escola ajuda;

        //LENDO OS PARAMETROS DO TERMINAL.
        //DIFERENCIANDO ID UNICO PARA .TXT.
        //CONDICAO DE ARQUIVOS DE IDS.TXT.
        if(!strcmp(argv[1],"-b")){
            strcpy(arquivoIds, argv[2]);
            flagDeIds = 1;

        if(!strcmp(argv[3],"-d")){
            strcpy(arquivoBusca, argv[4]);
        }

        if(!strcmp(argv[5],"-M")){
            tamanhoHash = atoi(argv[6]);
        }

        if(!strcmp(argv[7], "-mod")){
            keyMod = atoi(argv[8]);
        }

        //SE E PRA IMPRIMIR OU NAO.
        if(argc == 10){
            flagImprimir = 1;
        }else {
            flagImprimir = 0;
        }


        }else{
        //CONDICAO DE BUSCA DO ID.
            if(atoi(argv[1])<0 ){
                puts("ID invalido");
            exit;
            }
        //ID VALIDO.
            flagDeIds =0;
            idProcurar = atoi(argv[1]);

            if(!strcmp(argv[2],"-d")){
                strcpy(arquivoBusca, argv[3]);
            }

            if(!strcmp(argv[4],"-M")){
                tamanhoHash = atoi(argv[5]);
            }

            if(!strcmp(argv[6], "-mod")){
            keyMod = atoi(argv[7]);
        }

        //SE E PARA IMPRIMIR OU NAO.
            if(argc == 9){
                flagImprimir = 1;
            }else{
                flagImprimir = 0;
            }

        }

        //ABRINDO OS .TXT
        //ABRINDO ARQUIVO DE IDS.TXT CASO NECESSARIO.
        if(flagDeIds == 1){
            arqIds = fopen(arquivoIds , "r");   
        }

            arqBusca = fopen(arquivoBusca , "r");
        
        
        //VERIFICANDO SE FOI POSSIVEL ABRIR O ARQUIVO DESTINO.
        if(flagDeIds == 1){
        if(arqIds == NULL){
		    printf("Erro ao abrir arquivo de ids.\n");
		    exit;
	        }
        }
        
        if(arqBusca == NULL){
            printf("Erro ao abrir arquivo de destino\n");
            exit;
        }


        //ALOCANDO O ESPAÇO DA TABELA HASH
        hash* tabelaHash = (hash *)malloc(tamanhoHash*sizeof(hash));
        if(!tabelaHash){
        puts("erro ao alocar\n");
        exit;
        }

        //INICIALIZANDO AS LISTAS
        int i=0;
        while(i<tamanhoHash){
           tabelaHash[i].l = criaLista();
            i++;
        }




        //PEGANDO AS ESCOLAS UMA A UMA E SALVANDO NOS NÓS
        //PARA ADICIONAR A LISTA.
        escola e;
        int hashKey;
        int cont;
        int pos=0;

        t = clock();
        while(!feof(arqBusca)){
            escola xisde;
            cont =0;
            fgets(aux,110,arqBusca);
            token = strtok(aux,separa);
            while(token != NULL){
                cont++;
                if (cont == 1){
                    e.id = atoi(token);
                }

                else if ( cont == 2 ){
                    strcpy(e.estado, token);
                }

                else if ( cont == 3){
                    strcpy(e.municipio, token);
                }

                else if ( cont == 4){
                    strcpy(e.rede, token);
                }

                else if ( cont == 5){
                    e.media_ciencias_natureza = atof(token);
                }

                else if ( cont == 6){
                    e.media_ciencias_humanas = atof(token);
                }

                else if ( cont == 7){
                    e.media_linguagem = atof(token);
                }

                else if ( cont == 8){
                    e.media_matematica = atof(token);
                }

                else if ( cont == 9){
                    e.media_redacao = atof(token);
                }

                token = strtok(NULL,separa);

            //printf("CONT = %d POS = %d \n", cont , pos);
        
        }//FIM DO WHILE DAS INFORMAÇÕES

        hashKey = e.id%keyMod;

        xisde = buscaLista(*tabelaHash[hashKey].l,e.id);
        if(xisde.id<0){
           insereLista(tabelaHash[hashKey].l,e);
        }else{
            colisao++;
        }
        pos++;

        }//FIM DO WHILE DAS LINHAS DO arqBusca.txt

        //FIM DO CRONOMETRO DE TEMPO.
        t = clock() - t;
        //

        if(flagDeIds == 1){
            while(!feof(arqIds)){
                fgets(aux,30,arqIds);
                txtIds = atoi(aux);

                    if(txtIds>0){
                        hashKey = txtIds%keyMod;
                        ajuda = buscaLista(*tabelaHash[hashKey].l,txtIds);
                        if(ajuda.id<0){
                            printf("nao existe ID = %d \n", txtIds);
                        }else{           
                        if(flagImprimir==0){
                            printf("escola existe ID = %d \n", txtIds); 
				                          
                        }
                        else if(flagImprimir==1){
                            imprimirEscola(ajuda);
                        }
                        }

                        }
            }
            imprimeInfos(tabelaHash, tamanhoHash,t,colisao);
        }


        if(flagImprimir == 0){
        temp = (idProcurar%keyMod);
       
        ajuda =buscaLista(*tabelaHash[temp].l , idProcurar);

        if(ajuda.id<0){
            printf("nao existe ID = %d \n", txtIds);
            imprimeInfos(tabelaHash, tamanhoHash,t,colisao);
        }else{
            printf("escola existe ID = %d \n", txtIds);
            imprimeInfos(tabelaHash, tamanhoHash,t,colisao);
        }

        }
        if(flagImprimir == 1){
            temp = (idProcurar%keyMod);
            ajuda =buscaLista(*tabelaHash[temp].l , idProcurar);

        if(ajuda.id<0){
            printf("nao existe ID = %d \n", txtIds);
            imprimeInfos(tabelaHash, tamanhoHash,t,colisao);
        }else{
            imprimirEscola(ajuda);
            imprimeInfos(tabelaHash, tamanhoHash,t,colisao);
        }
        }


    
    }

