#!/bin/bash
chmod +x runcode.sh

exeFile="./src/executavel"
libH="./src/register.h"
libC="./src/register.c"
main="./src/main.c"

gcc -o $exeFile $libH $libC $main
./$exeFile
rm $exeFile