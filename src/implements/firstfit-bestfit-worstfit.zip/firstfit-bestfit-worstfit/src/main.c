#include <stdio.h>
#include <stdlib.h>
#include "register.h"

int main(int argc, char const *argv[]) {

  item_t blockSize[] = {100,500,200,300,600};
  item_t processSize[] = {212,417,112,426};
  item_t m = sizeof(blockSize)/sizeof(blockSize[0]);
  item_t n = sizeof(processSize)/sizeof(processSize[0]);

  printf("\nFirst Fit:\n");
  firstFit(blockSize, m, processSize, n);
  printf("\nBest Fit:\n");
  bestFit(blockSize, m, processSize, n);
  printf("\nWorst Fit:\n");
  worstFit(blockSize, m, processSize, n);

  return 0;
}