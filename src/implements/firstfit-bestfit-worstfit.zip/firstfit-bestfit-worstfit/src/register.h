#ifndef REGISTER_H_INCLUDED
#define REGISTER_H_INCLUDED

typedef unsigned int item_t;

void firstFit(item_t blockSize[], item_t m, item_t processSize[], item_t n);
void bestFit(item_t blockSize[], item_t m, item_t processSize[], item_t n);
void worstFit(item_t blockSize[], item_t m, item_t processSize[], item_t n);

#endif