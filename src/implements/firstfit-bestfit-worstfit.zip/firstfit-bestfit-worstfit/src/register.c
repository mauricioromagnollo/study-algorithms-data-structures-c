#include "register.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void firstFit(item_t blockSize[], item_t m, item_t processSize[], item_t n) {
  item_t allocation[n];
  memset(allocation, -1, sizeof(allocation));

  for(item_t i=0; i<n; i++) {
    for(item_t j=0; j<m; j++) {
      if(blockSize[j] >= processSize[i]) {
        allocation[i] = j;
        blockSize[j] -= processSize[i];
        break;
      }
    }
  }

  printf("\nProcess Nº\tProcess Size\tBlock Nº\n");

  for(item_t i=0; i<n; i++) {
    printf("%u\t\t%u",i+1,processSize[i]);
    if(allocation[i] != -1) {
      printf("%u", allocation[i] + 1);
    } else {
      printf("Not Allocated");
    }
  }
}

void bestFit(item_t blockSize[], item_t m, item_t processSize[], item_t n) {
  item_t allocation[n];
  memset(allocation, -1, sizeof(allocation));
  for(item_t i=0; i<n; i++) {
    item_t bestIdx = -1;
    for(item_t j=0; j<m; j++) {
      if(blockSize[j] >= processSize[i]) {
        if(bestIdx == -1) bestIdx = j;
        else if(blockSize[bestIdx] > blockSize[j]) bestIdx = j;
      }
    }

    if(bestIdx != -1) {
      allocation[i] = bestIdx;
      blockSize[bestIdx] -= processSize[i];
    }
  }

  printf("\nProcess Nº\tProcess Size\tBlock Nº\n");
  for(item_t i=0; i<n; i++) {
    printf("%u\t\t%u\t\t",i+1,processSize[i]);
    if(allocation[i] != -1) printf("%u", allocation[i] + 1);
    else printf("Not Allocated");
  }
}

void worstFit(item_t blockSize[], item_t m, item_t processSize[], item_t n) {
  item_t allocation[n];

  memset(allocation, -1, sizeof(allocation));

  for(item_t i=0; i<n; i++) {
    item_t wstIdx = -1;
    for(item_t j=0; j<m; j++) {
      if(blockSize[j] >= processSize[i]) {
        if(wstIdx == -1) {
          wstIdx = j;
        } else if(blockSize[wstIdx] < blockSize[j]) {
          wstIdx = j;
        }
      }
    }

    if(wstIdx != -1) {
      allocation[i] = wstIdx;
      blockSize[wstIdx] -= processSize[i];
    }
  }

  printf("\nProcess Nº\tProcess Size\tBlock Nº\n");
  for(item_t i=0; i<n; i++) {
    printf("%u\t\t%u\t\t",i+1,processSize[i]);
    if(allocation[i] != -1)
      printf("%u", allocation[i] + 1);
    else
      printf("Not Allocated\n");
  }
}
