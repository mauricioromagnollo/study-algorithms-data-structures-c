/*******************************************************************************
 * Atividade: Trabalho Prático (PROG I)
 * Trabalho:  Todo List
 * Aluno:     Lucas Alvarenga Silva Vilaça
 * Matrícula: 19.1.8167
 *******************************************************************************/ 

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <time.h>
#include <string.h>

/* Verificar Se Está Rodando no Unix ou Windows */
#ifdef __unix__
  #include <unistd.h>
#elif defined(_WIN32) || defined(WIN32)
  #include <windows.h>
#endif

/* Constantes */
#define NOME_ARQUIVO_DE_DADOS "data.dat"

#define ADICIONAR_LISTA_DE_TAREFAS 1
#define REMOVER_LISTA_DE_TAREFAS 2
#define ABRIR_LISTA_DE_TAREFA 3
#define LISTAR_TAREFAS_DE_UM_PERIODO 4
#define SAIR_FECHAR_PROGRAMA 0

#define ADICIONAR_TAREFA 1
#define REMOVER_TAREFA 2
#define MARCAR_TAREFA_COMO_FEITA 3
#define MARCAR_TAREFA_COMO_NAO_FEITA 4
#define MUDAR_PRIORIDADE_DO_ITEM 5
#define VOLTAR_AO_MENU_PRINCIPAL 0

/* Tipo Boolean */
typedef enum { false, true } bool;

/* Funções do Sistema */
void pausarAlgoritmo(unsigned int);
void limparTelaDoTerminal();
void utf8();
void limparBuffer();

/* Tipo Data */
typedef unsigned short int dia_t, mes_t; 
typedef unsigned int ano_t;

typedef struct {
  dia_t dia;
  mes_t mes;
  ano_t ano;
}data_t;

data_t getDataAtual();
data_t getNovaData(dia_t, mes_t, ano_t);
bool isMesmaData(data_t, data_t);
void imprimeData(data_t);
bool isDataAnterior(data_t, data_t);

/* Tipo Hora */
typedef unsigned short int hora_t, minuto_t, segundo_t;

typedef struct {
  hora_t hora;
  minuto_t minuto;
  segundo_t segundo;
}horario_t;

horario_t getHoraAtual();
horario_t getNovoHorario(hora_t, minuto_t, segundo_t);
bool isMesmaHora(horario_t, horario_t);
bool isHoraAnterior(horario_t, horario_t, bool);
void imprimeHora(horario_t);

/* Tipo Todo List */
typedef unsigned int id_t;
typedef const char descricao_t[30];
typedef char nome_t[15];
typedef unsigned short int menu_t;

typedef struct {
  id_t id;
  descricao_t descricao;
  data_t dataInicio;
  data_t dataFinal;
  bool isTarefaFeita;
}tarefa_t;

typedef struct node_lista_de_tarefas *lista_de_tarefas_ptr_t;

typedef struct node_lista_de_tarefas {
  tarefa_t tarefa;
  lista_de_tarefas_ptr_t prox;
}node_lista_de_tarefas_t;

typedef struct {
  lista_de_tarefas_ptr_t primeiro, ultimo;
}lista_de_tarefas_t;

typedef struct {
  id_t id;
  nome_t nome;
  descricao_t descricao;
  lista_de_tarefas_t listaDeTarefas;
}todolist_t;

typedef struct node_todo_list *node_todo_list_ptr_t;

typedef struct node_todo_list {
  todolist_t todolist;
  node_todo_list_ptr_t prox;
}node_todo_list_t;

typedef struct {
  node_todo_list_ptr_t primeiro, ultimo;
}todolists_t;

// tarefa_t getNovaTarefa(descricao_t, data_t, data_t);
void setTarefaFeita(tarefa_t *, bool);
void setId(tarefa_t *, id_t);

menu_t getMenuPrincipal();
menu_t getMenuAbrirListaDeTarefas();

data_t getInputData();
id_t getInputId();
int getNumRand(int initValue, int endValue);

void criarTodoListsVazia(todolists_t *todolists);
void criarListaDeTarefasVazia(lista_de_tarefas_t *listadetarefas);
void criarTodoListVazia(todolist_t *todolist);
todolist_t newTodoList(const nome_t nome, const descricao_t descricao);

// =============================================================================
int main() {
  menu_t menuPrincipal = 1, menuAbrirListaDeTarefa = 1;
  todolists_t todolists;

  criarTodoListsVazia(&todolists);

  utf8();
  limparTelaDoTerminal();

  // Verificar Se Algum Arquivo .dat já foi criado
    // Caso tenha sido criado é porquê existem dados salvos na última execução do programa
      // Buscar os dados no arquivo e ir alocando nas estruturas
    // Caso não tenha sido criado, criar um arquivo .dat para salvar os dados dessa execução

  while (menuPrincipal) {
    limparTelaDoTerminal();
    menuPrincipal = getMenuPrincipal();

    switch (menuPrincipal) {
      case ADICIONAR_LISTA_DE_TAREFAS:
        // ...
        break;
      
      case REMOVER_LISTA_DE_TAREFAS:
        // Exibir as Listas de Tarefas Disponíveis e os ID
        // Pedir o Usuário o ID pelo Input do Teclado de qual lista ele deseja remover
        // Buscar Lista por ID e dar free(listadetarefas)
        break;
      
      case ABRIR_LISTA_DE_TAREFA:
        // exibir as listas de tarefas disponíveis
        // Pedir o Usuário o ID pelo Input do Teclado de qual lista ele deseja abrir
        // Buscar Lista por ID e pegar o endereço de memória
        while (menuAbrirListaDeTarefa) {
          switch (menuAbrirListaDeTarefa) {
            case ADICIONAR_TAREFA:
              /* code */
              break;
            case REMOVER_TAREFA:
              /* code */
              break;
            case MARCAR_TAREFA_COMO_FEITA:
              /* code */
              break;
            case MARCAR_TAREFA_COMO_NAO_FEITA:
              /* code */
              break;
            case MUDAR_PRIORIDADE_DO_ITEM:
              /* code */
              break;
            case VOLTAR_AO_MENU_PRINCIPAL:
              /* code */
              break;
            
            default:
              printf("[!] Opção Inválida, tente novamente...\n");
              pausarAlgoritmo(2);
              break;
          }
        }
        
        break;
 
      case LISTAR_TAREFAS_DE_UM_PERIODO:
        // Pedir o usuário o Input da Data pelo teclado
        // Buscar todas as Tarefas em todas as listas que possuem esta data
        // Ir Exibindo ao encontrar
        break;
 
      case SAIR_FECHAR_PROGRAMA:
        printf("[!] Saindo do Programa...\n");
        pausarAlgoritmo(2);
        break;

      default:
        printf("[!] Opção Inválida, tente novamente...\n");
        pausarAlgoritmo(2);
        break;
    }
  }
  
  return 0;
}
// =============================================================================

void pausarAlgoritmo(unsigned int tempoEmSegundos) {
  #ifdef __unix__
    sleep(tempoEmSegundos);
  #elif defined(_WIN32) || defined(WIN32)
    Sleep(tempoEmSegundos * 1000);
  #endif 
}

void limparTelaDoTerminal() {
  #ifdef __unix__
    system("clear");
  #elif defined(_WIN32) || defined(WIN32)
    system("cls");
  #endif  
}

void utf8() {
  setlocale(LC_ALL,"");
}

void limparBuffer() {
  #ifdef __unix__
    __fpurge(stdin);
  #elif defined(_WIN32) || defined(WIN32)
    fflush(stdin);
  #endif  
}

data_t getDataAtual() {
  time_t t = time(NULL);
  struct tm tm = *localtime(&t);
  return (data_t) {
    (dia_t)(tm.tm_mday), 
    (mes_t)(tm.tm_mon + 1), 
    (ano_t)(tm.tm_year + 1900)
  };
}

data_t getNovaData(dia_t dia, mes_t mes, ano_t ano) {
  return (data_t){ dia, mes, ano };
}

bool isMesmaData(data_t data1, data_t data2) {
  return (
    data1.dia == data2.dia && 
    data1.mes == data2.mes && 
    data1.ano == data2.ano
  );
}

void imprimeData(data_t data) {
  printf("%02d/%02d/%d", data.dia, data.mes, data.ano);
}

bool isDataAnterior(data_t data1, data_t data2) {
  if (data1.ano < data2.ano) {
    return true;
  } 
  if (data1.ano == data2.ano) {
    if (data1.mes < data2.mes) {
      return true;
    }
    if (data1.mes == data2.mes) {
      if (data1.dia < data2.dia) {
        return true;
      }
      if (data1.dia == data2.dia) {
        return false;
      }
    }
  }
  return false;
}

horario_t getHoraAtual() {
  time_t t = time(NULL);
  struct tm tm = *localtime(&t);
  return (horario_t) {
    (hora_t)(tm.tm_hour),
    (minuto_t)(tm.tm_min),
    (segundo_t)(tm.tm_sec),
  };  
}

horario_t getNovoHorario(hora_t hora, minuto_t minuto, segundo_t segundo) {
  return (horario_t){ hora, minuto, segundo };
}

bool isMesmaHora(horario_t hora1, horario_t hora2) {
  return (
    hora1.hora == hora2.hora &&
    hora1.minuto == hora2.minuto
  );
}

bool isHoraAnterior(horario_t hora1, horario_t hora2, bool isVerificarOsSegundos) {
  if (hora1.hora < hora2.hora) {
    return true;
  }
  if (hora1.hora == hora2.hora) {
    if (hora1.minuto < hora2.minuto) {
      return true;
    }
    if (isVerificarOsSegundos) {
      if (hora1.minuto == hora2.minuto) {
        if (hora1.segundo < hora1.segundo) {
          return true;
        }
      }
    }
  }

  return false;
}

void imprimeHora(horario_t horario) {
  printf("%02d:%02d:%02d", horario.hora, horario.minuto, horario.segundo);
}

tarefa_t getNovaTarefa(descricao_t descricao, data_t dataInicio, data_t dataFinal) {
  tarefa_t tarefa;

  tarefa.id = getNumRand(0, 1000);
  // strcpy(tarefa.descricao, descricao);
  tarefa.dataInicio = dataInicio;
  tarefa.dataFinal = dataFinal;
  tarefa.isTarefaFeita = false;

  return (tarefa_t)tarefa;
}

void setTarefaFeita(tarefa_t *tarefa, bool isFeita) {
  tarefa->isTarefaFeita = (isFeita) ? true : false;
}

void setId(tarefa_t *tarefa, id_t ultimoId) {
  tarefa->id = (ultimoId + 1);
}

menu_t getMenuPrincipal() {
  menu_t menu;
  printf("  *** TODO LIST - MENU ***\n");
  printf("---------------------------------\n");
  printf("1 - Adicionar Lista de Tarefas\n");
  printf("2 - Remover Lista de Tarefas\n");
  printf("3 - Abrir Lista de Tarefas\n");
  printf("4 - Listar Tarefas de Um Período\n");
  printf("0 - Sair / Fechar Programa\n");
  printf("---------------------------------\n");
  printf("[*] Digite o número da opção desejada: ");
  scanf("%hi", &menu);
  return menu;
}

menu_t getMenuAbrirListaDeTarefas() {
  menu_t menu;
  printf("  *** LISTA DE TAREFAS - MENU ***\n");
  printf("---------------------------------\n");
  printf("1 - Adicionar Tarefa\n");
  printf("2 - Remover Tarefa\n");
  printf("3 - Marcar Tarefa Como Feita\n");
  printf("4 - Marcar Tarefa Como Não Feita\n");
  printf("5 - Mudar Prioridade do Item\n");
  printf("0 - Menu Principal\n");
  printf("---------------------------------\n");
  printf("[*] Digite o número da opção desejada: ");
  scanf("%hi", &menu);
  return menu;
}

data_t getInputData() {
  data_t data;
  printf("[*] Digite o Dia: ");
  scanf("%hi", &data.dia);

  printf("[*] Digite o Mês: ");
  scanf("%hi", &data.mes);

  printf("[*] Digite o Ano: ");
  scanf("%d", &data.ano);
  return data;
}

id_t getInputId() {
  id_t id;
  printf("[*] Digite o ID desejado: ");
  scanf("%d", &id);
  return id;
}

int getNumRand(int initValue, int endValue) {
  return (initValue + (rand() % (endValue - initValue)));
}

void criarTodoListsVazia(todolists_t *todolists) {
  todolists->primeiro = (node_todo_list_ptr_t)malloc(sizeof(node_todo_list_t));
  todolists->ultimo = todolists->primeiro;
  todolists->ultimo->prox = NULL;
}

void criarListaDeTarefasVazia(lista_de_tarefas_t *listadetarefas) {
  listadetarefas->primeiro = (lista_de_tarefas_ptr_t)malloc(sizeof(node_lista_de_tarefas_t));
  listadetarefas->ultimo = listadetarefas->primeiro;
  listadetarefas->ultimo->prox = NULL;
}

void criarTodoListVazia(todolist_t *todolist) {
  criarListaDeTarefasVazia(&todolist->listaDeTarefas);
}

todolist_t newTodoList(const nome_t nome, const descricao_t descricao) {
  todolist_t todolist;
  
  todolist.id = getNumRand(0, 1000);
  // strcpy(todolist.nome, nome);
  // strcpy(todolist.descricao, descricao);
  criarTodoListVazia(&todolist);
  
  return todolist;
}
