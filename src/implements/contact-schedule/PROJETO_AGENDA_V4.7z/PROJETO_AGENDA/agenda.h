#ifndef AGENDA_H_INCLUDED
#define AGENDA_H_INCLUDED

#ifdef __unix__
    #include <unistd.h>
#elif defined(_WIN32) || defined(WIN32)
    #include <windows.h>
#endif

/** ARQUIVO DE DADOS DA AGENDA */
#define FILENAME "agenda.dat"

/** DEFININDO TIPO BOOL */
#define TRUE 1
#define FALSE 0
typedef int bool;

/** ESTRUTURA DE DADOS AGENDA */
typedef struct {
    int codigo;
    char *nome;
    char *email;
    short int ddd;
    int telefone;
}Item;

typedef struct tipoCelula *Apontador;

typedef struct tipoCelula {
    Item item;
    Apontador prox;
}Celula;

typedef struct {
    Apontador primeiro, ultimo;
    int cont;
}Lista;

typedef Lista Agenda;
typedef Item Contato;

/** INTERFACE AGENDA */
int MenuAgenda();
bool Vazia(Agenda l);
void IniciaAgenda(Agenda *l);
void AddContato(Agenda *l);
void RemoveContato(Apontador p, Agenda *l, Contato *x);
void EditarContato(Agenda *l);
void Pesquisa(Apontador p, Agenda *l, Contato *x);
void ExibeAgenda(Agenda *l);
void EncerraAgenda(Agenda *l);
void EscreveAgenda(Agenda *l, char *fileName);
void LeAgenda(Agenda *l, char *fileName);

/** AUXILIARES */
Item getContato();
void setContato(Contato x, Agenda *l);
void exibeContato(Contato x);
Apontador buscaCodigo(int codigo, Agenda *l);
Apontador buscaNome(char *nome, Agenda *l);
void criaArquivo(char *fileName);
void removeArquivo(char *fileName);
bool existeArquivo(char *fileName);
void clear();
void buffclear();
void setUTF8();
int numrand(short int __init, short int __end);
void pausar(int t_seg);

#endif // AGENDA_H_INCLUDED