#!/bin/bash
chmod +x exec.sh

gcc -o exe agenda.c agenda.h main.c -lm; ./exe; rm exe