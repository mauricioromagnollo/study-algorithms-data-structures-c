#include <stdio.h>
#include <stdlib.h>
#include "agenda.h"

void Teste() {
	agenda_t *lista=NULL;
	FILE *fileContato=NULL;

	setUTF8();

	// verificar arquivo

	do {
		clear("buffer"); 
		clear("screen");
		printf("\n");
		printf("\t==========================\n");
		printf("\t  * AGENDA DE CONTATOS *\n");
		printf("\t==========================\n");
		mainOptions = Menu();

		switch(mainOptions) {
			case 0:
				break;
			case 1:
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				break;
			default:
				break;
		}

	}while(mainOptions != 0);

}