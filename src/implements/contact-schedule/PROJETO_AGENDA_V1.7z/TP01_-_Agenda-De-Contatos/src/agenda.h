/** TRABALHO PRÁTICO I - AEDS(CSI488)
 * Aluno:......Maurício Romagnoli
 * Num.Matr.:..16.2.8315
 * Arquivo:....(agenda.h)
*/

#include <stdio.h>
#include <stdlib.h>

#ifndef AGENDA_H
#define AGENDA_H

/*
 * Estrutura de dados do Contato:
 */

typedef struct contato {
	int codigo;
	char * nome;
	char * email;
	short int ddd;
	int numero;
}contato_t;

typedef struct agenda {
	contato_t contato[SIZEMAX];
	int * n;
}agenda_t;

/*
 * Constantes:
 */
#define SIZEMAX 100
#define FILENAME "agenda.list"
/*
 * Macros:
 */
#define ALOCAR(obj) do { obj = malloc(sizeof(obj[0]));if (!obj) exit(1);} while (0)
#define REALOCAR(obj) do { obj = realloc(obj,sizeof(obj[0]));if (!obj) exit(1);} while (0)
#define REMOVER(obj) (free(obj))
/*
 * Funções Auxiliares:
 */
void setUTF8();
void clear(const char *str);
contato_t novo(int *, char *, char *, short int *, int *);
/*
 * Interface:
 */
void Exibir(contato_t *, int *);
void Adicionar(contato_t *, int *);
void Remover(contato_t *, int *);


void Teste();
void TesteMain();
#endif 
// fim