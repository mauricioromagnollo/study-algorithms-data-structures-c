/** TRABALHO PRÁTICO I - AEDS(CSI488)
 * Aluno:......Maurício Romagnoli
 * Num.Matr.:..16.2.8315
 * Arquivo:....(agenda.c)
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <unistd.h> 
#include "agenda.h"

void setUTF8() {
	setlocale(LC_ALL,"");	
}

void clear(const char *str) {
	#ifdef __unix__
		if(strcmp(str,"screen") == 0)
			system("clear");
		else if(strcmp(str,"buffer") == 0)	
			__fpurge(stdin);	
	#elif defined(_WIN32) || defined(WIN32)
		if(strcmp(str,"screen") == 0)
			system("cls");
		else if(strcmp(str,"buffer") == 0)	
			fflush(stdin);	
	#else
		printf("\t[!] Erro: void clear()\n");
	#endif
}


contato_t novo(int codigo, char *nome, char *email, short int ddd, int num) {
	contato_t c;

	c.codigo = codigo;

	c.nome = (char *)malloc(strlen(nome) * sizeof(char));
	strcpy(c.nome,nome);

	c.email = (char *)malloc(strlen(email) * sizeof(char));
	strcpy(c.email,email);
	
	c.ddd = ddd;
	c.numero = num;		
	return c;
}

void Exibir(contato_t *c, int i) {
	printf("\n");
	printf("----------------------------------\n");
	printf("Nome:....%s\n",c[i].nome);
	printf("Código:..%d\n",c[i].codigo);	
	printf("Email:...%s\n",c[i].email);
	printf("Número:..(%hi) 9%d\n",c[i].ddd,c[i].numero);
	printf("----------------------------------\n");
}

/*
void Excluir(contato_t *c, int i) {

}
*/