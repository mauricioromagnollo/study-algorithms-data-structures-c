/** TRABALHO PRÁTICO I - AEDS(CSI488)
 * Aluno:......Maurício Romagnoli
 * Num.Matr.:..16.2.8315
 * Arquivo:....(main.c)
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "agenda.h"

int main(int argc, char const *argv[])
{
	Teste();

	return 0;
}
