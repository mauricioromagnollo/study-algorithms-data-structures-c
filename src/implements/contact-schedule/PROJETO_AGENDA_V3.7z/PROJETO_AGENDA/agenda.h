#ifndef AGENDA_H_INCLUDED
#define AGENDA_H_INCLUDED

#ifdef __unix__
    #include <unistd.h>
#elif defined(_WIN32) || defined(WIN32)
    #include <windows.h>
#endif

/** ARQUIVO DE DADOS DA AGENDA */
#define FILENAME "agenda.dat"

/** DEFININDO TIPO BOOL */
#define TRUE 1
#define FALSE 0
typedef int bool;

/** ESTRUTURA DE DADOS AGENDA */
typedef struct {
    int codigo;
    char *nome;
    char *email;
    short int ddd;
    int telefone;
}Item;

typedef struct aux *apontador;

typedef struct aux {
    Item item;
    apontador prox;
}Celula;

typedef struct {
    apontador primeiro, ultimo;
    int cont;
}Lista;

typedef Lista Agenda;
typedef Item Contato;

/** INTERFACE AGENDA */
int MenuAgenda();
void IniciaAgenda(Agenda *l);
void AddContato(Contato x, Agenda *l);
//void RemoveContato(Agenda *l);
//void EditarContato(Agenda *l);
//void Pesquisa(Agenda *l);
void Exibe(Agenda *l);
//void EncerraAgenda(Agenda *l);

/** AUXILIARES */
bool vazia(Agenda l);
Item getContato();
apontador buscaCodigo(int codigo, Agenda *l);
apontador buscaNome(char *nome, Agenda *l);
void criaArquivo(char *fileName);
void removeArquivo(char *fileName);
bool existeArquivo(char *fileName);
void escreveDadosArquivo(char *fileName, Lista *l);
//leDadosArquivo(char *fileName, Agenda *l);
void clear();
void buffclear();
void setUTF8();
int numrand(short int __init, short int __end);
void pausar(int t_seg);

/** INTERFACE LISTA */
bool retira(apontador p, Lista *l, Item *x);
bool altera(Lista *l);
bool libera(Lista *l);
void exibeItem(Item x);

#endif // AGENDA_H_INCLUDED
