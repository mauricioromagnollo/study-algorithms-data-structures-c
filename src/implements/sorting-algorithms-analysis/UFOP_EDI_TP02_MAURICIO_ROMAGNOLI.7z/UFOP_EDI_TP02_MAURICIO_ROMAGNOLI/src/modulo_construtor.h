#ifndef MODULO_CONSTRUTOR_H_INCLUDED
#define MODULO_CONSTRUTOR_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <time.h>

#ifdef __unix__
    #include <unistd.h>
#elif defined(_WIN32) || defined(WIN32)
    #include <windows.h>
#endif

enum { NULL_OS, LINUX_OS, WINDOWS_OS, MAC_OS };
enum { RED, GREEN };
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_RESET   "\x1b[0m"

typedef enum { false, true } bool;

/* Constantes do Menu */
#define CRIAR_ARQUIVO 1
#define FAZER_ANALISE 2
#define SAIR_DO_PROGRAMA 3

/* Define Tipo Arquivo */
#define QUANT_ARQUIVOS 3
#define QUANT_ALGORITMOS 4
#define DELIM ','
#define EXTENSAO_ARQ ".dat"
#define PADRAO_ARQ "0%d_%d.dat"

enum { VAZIO, CRESCENTE, DECRESCENTE, RANDOM };

typedef int indice_t;
typedef int chave_t;

typedef struct {
    char *nome;
    short int tipoOrdenacao;
    int qtdeNum;
    chave_t *array;
}arquivo_t;

typedef struct {
    char *algoritmoDeTeste;
    int numComparacoes;
    int numExecucoes;
    double tempoDeExecucao;
}analise_t;

#define TROCA(a,b) \
    chave_t tmp;   \
    tmp = *a;      \
    *a = *b;       \
    *b = tmp;      \

/** Interface Módulo Construtor */



/** Módulo Aux */
short int getMenu();
bool isNull(FILE *file);
bool writefiles(FILE *file, int qtdeNum);
bool readArrayInFile(chave_t *vet, int qtdeNum, char *fileName);
void exibeDadosDoArquivo(arquivo_t arquivo);
void exibeAnalise(analise_t analise, int indiceArquivo);
void exibeItens(chave_t itens[], int size);
int getQtdeNumGerados();
arquivo_t newFile(int tipoOrdenacao, int qtdeNum);
void analisaSelec(arquivo_t arquivo, analise_t *analise);
void analisaShell(arquivo_t arquivo, analise_t *analise);
void analisaInsertion(arquivo_t arquivo, analise_t *analise);
void analisaQuick(arquivo_t arquivo, analise_t *analise);
void gerarRelatorio(arquivo_t *arquivo, analise_t *analise);

/** Algoritmos de Ordenação */
void selectionSort(chave_t *vet, int n, int *numComp, int *numExec);
void shellSort(chave_t *vet, int size, int *numComp, int *numExec);
void insertionSort(chave_t *vet, int n, int *numComp, int *numExec);
void quickSort(chave_t vet[], int esq, int dir, int *numComp, int *numExec);
void ordenaDecrescente(chave_t *vet, int n);

/** Sys Aux */
void setLocaleLang();
short int getOpSys();
void clear();
void buffclear();
void pausar(int tSeg);
void alert(const char *str, int color, int tSecPause);
int numrand(int vInicial, int vFinal);
double getTimeExec(clock_t init, clock_t end);

#endif // MODULO_CONSTRUTOR_H_INCLUDED
