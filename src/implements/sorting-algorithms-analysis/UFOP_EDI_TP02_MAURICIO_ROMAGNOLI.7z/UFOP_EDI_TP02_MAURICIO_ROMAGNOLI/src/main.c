#include "modulo_construtor.h"

int main()
{
    arquivo_t arquivo[QUANT_ARQUIVOS];
    analise_t analise[QUANT_ARQUIVOS * QUANT_ALGORITMOS];
    FILE *file;
    bool sair = false;
    bool arquivosCriados = false;
    int qtdeNumGerados;
    
    while(!sair) {
        clear();
        switch(getMenu()) {
            case CRIAR_ARQUIVO:
                qtdeNumGerados = getQtdeNumGerados();
                buffclear();
                writefiles(file, qtdeNumGerados);
                arquivosCriados = true;
                break;
            
            case FAZER_ANALISE:
                buffclear();
                if(arquivosCriados) {
                    for(int i=0; i<QUANT_ARQUIVOS; i++) {
                        arquivo[i] = newFile((i+1), qtdeNumGerados);
                    }

                    for(int i=0, j=0; i<QUANT_ARQUIVOS; i++) {
                        analisaSelec(arquivo[i], &analise[j]);
                        j+=1;
                        analisaShell(arquivo[i], &analise[j]);
                        j+=1;
                        analisaInsertion(arquivo[i], &analise[j]);
                        j+=1;
                        analisaQuick(arquivo[i],&analise[j]);
                        j+=1;
                    }

                    gerarRelatorio(arquivo,analise);

                    // for(int i=0,j=0; i<QUANT_ARQUIVOS*QUANT_ALGORITMOS; i++) {
                    //     exibeAnalise(analise[i],j);                   
                    // }

                    // pausar(100);

                } else {
                    alert("Você deve criar os arquivos \".dat\" para realizar os testes", RED, 2);
                }          
                break;
            
            case SAIR_DO_PROGRAMA:
                alert("Saindo do programa..\n", GREEN, 2);
                sair = true;
                break;    
            
            default:
                alert("Opção inválida!\n", RED, 2);
                sair = false;
                break;                
        }
    }    
    return 0;
}