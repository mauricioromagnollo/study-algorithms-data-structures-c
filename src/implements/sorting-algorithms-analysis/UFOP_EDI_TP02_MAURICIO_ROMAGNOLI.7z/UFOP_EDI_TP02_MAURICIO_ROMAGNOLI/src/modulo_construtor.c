
#include "modulo_construtor.h"

// -------------------------------------------------------------

short int getMenu() {
    short int op;
    printf("\n--------------------\n");
    printf("1 - Construção de arquivos\n");
    printf("2 - Análise Comparativa\n");
    printf("3 - Sair\n");
    printf("--------------------\n");
    scanf("%hi", &op);
    return(op);
}

bool isNull(FILE *file) {
    return(file == NULL);
}

bool writefiles(FILE *file, int qtdeNum) {
    char fileName[100];
    int vet[qtdeNum],vetRand[qtdeNum];
    bool check = false;
    int cont1=0,cont2=0;

    for(int i=0; i<qtdeNum; i++) 
        vet[i] = numrand(0,1000);

    buffclear();
    sprintf(fileName,PADRAO_ARQ,RANDOM,qtdeNum);
    file = fopen(fileName, "wb");
    if(!isNull(file)) {
        for(int i=0; i<qtdeNum; i++)    fprintf(file,"%d%c",vet[i],DELIM);
        fclose(file);
        check = true;
    } else {
        check = false;
    }
    buffclear();
    sprintf(fileName,PADRAO_ARQ,CRESCENTE,qtdeNum);
    file = fopen(fileName, "wb");
    if(!isNull(file)) {
        quickSort(vet,0,qtdeNum,&cont1,&cont2);
        for(int i=0; i<qtdeNum; i++)    fprintf(file,"%d%c",vet[i],DELIM);
        fclose(file);
        check = true;
    } else {
        check = false;
    }
    buffclear();
    sprintf(fileName,PADRAO_ARQ,DECRESCENTE,qtdeNum);
    file = fopen(fileName, "wb");
    if(!isNull(file)) {
        ordenaDecrescente(vet,qtdeNum);
        for(int i=0; i<qtdeNum; i++)    fprintf(file,"%d%c",vet[i],DELIM);
        fclose(file);
        check = true;
    } else {
        check = false;
    }

    return check;

}

bool readArrayInFile(chave_t *vet, int qtdeNum, char *fileName) {
    FILE *file;
    file = fopen(fileName, "rb");
    if(isNull(file)) {
        return false;
    } else {
        char ch;
        int i=0;
        for(int i=0; i<qtdeNum && !feof(file);i++)
            fscanf(file, "%d%c",&vet[i],&ch);   
    }
    fclose(file);
    return true;
}

void exibeDadosDoArquivo(arquivo_t arquivo) {
    printf("\n\n-----------------------------\n");
    printf("Arquivo:........%s\n",arquivo.nome);
    printf("Tipo Ordenação:.0%d\n", arquivo.tipoOrdenacao);
    printf("Qtde. Num:......%d\n", arquivo.qtdeNum);
    exibeItens(arquivo.array,arquivo.qtdeNum);
    printf("-----------------------------\n");
}

void exibeAnalise(analise_t analise, int indiceArquivo) {
    alert("------------PRINTING ANALISYS--------------", GREEN, 0);
    printf("\nAlgotimo:..........%s",analise.algoritmoDeTeste);
    printf("\nArquivo:...........(%d)",indiceArquivo);
    printf("\nNúm. Comparações:..%d", analise.numComparacoes);
    printf("\nNum. Trocas:.......%d", analise.numExecucoes);
    printf("\nTempo Exec.:.......%lf ms.", analise.tempoDeExecucao);
    alert("---------------END ANALISYS----------------\n", GREEN, 0);
}

void exibeItens(chave_t vet[], int vetSize) {
    alert("**************PRINTING_ITENS********************\n", GREEN, 0);
    for(int i=0; i<vetSize; i++)    printf("[%d]",vet[i]);
    alert("**************END_PRINT_ITENS*******************\n", GREEN, 0);
}

int getQtdeNumGerados() {
    int qtde;
    alert("Digite a quantidade de números a serem gerados:\n> ", GREEN, 0);
    scanf("%d", &qtde);
    return (qtde);
}

arquivo_t newFile(int tipoOrdenacao, int qtdeNum) { //..

    arquivo_t arq;
    char str[20];
    
    arq.tipoOrdenacao = tipoOrdenacao;
    arq.qtdeNum = qtdeNum;

    sprintf(str, PADRAO_ARQ, arq.tipoOrdenacao, arq.qtdeNum); 
    arq.nome = (char *)malloc(strlen(str) * sizeof(char));
    strcpy(arq.nome, str);
    
    arq.array = (chave_t *)malloc(qtdeNum  * sizeof(chave_t));
    readArrayInFile(arq.array,arq.qtdeNum,arq.nome);
    
    return arq;
}

void analisaSelec(arquivo_t arquivo, analise_t *analise) {
    clock_t init, end;
    chave_t vetAux[arquivo.qtdeNum];
    
    for(int i=0; i<arquivo.qtdeNum; i++) vetAux[i] = arquivo.array[i];

    analise->algoritmoDeTeste = (char *)malloc(strlen("Selection Sort") * sizeof(char));
    strcpy(analise->algoritmoDeTeste,"Selection Sort");

    init = clock();
    selectionSort(vetAux,arquivo.qtdeNum,&analise->numComparacoes,&analise->numExecucoes);
    end = clock();
    analise->tempoDeExecucao = getTimeExec(init, end);
}

void analisaShell(arquivo_t arquivo, analise_t *analise) {
    clock_t init, end;
    chave_t vetAux[arquivo.qtdeNum];
    
    for(int i=0; i<arquivo.qtdeNum; i++) vetAux[i] = arquivo.array[i];

    analise->algoritmoDeTeste = (char *)malloc(strlen("Shell Sort") * sizeof(char));
    strcpy(analise->algoritmoDeTeste,"Shell Sort");

    init = clock();
    shellSort(vetAux,arquivo.qtdeNum,&analise->numComparacoes,&analise->numExecucoes);
    end = clock();
    analise->tempoDeExecucao = getTimeExec(init, end);    
}

void analisaInsertion(arquivo_t arquivo, analise_t *analise) {
    clock_t init, end;
    chave_t vetAux[arquivo.qtdeNum];
    
    for(int i=0; i<arquivo.qtdeNum; i++) vetAux[i] = arquivo.array[i];

    analise->algoritmoDeTeste = (char *)malloc(strlen("Insertion Sort") * sizeof(char));
    strcpy(analise->algoritmoDeTeste,"Insertion Sort");

    init = clock();
    insertionSort(vetAux,arquivo.qtdeNum,&analise->numComparacoes,&analise->numExecucoes);
    end = clock();
    analise->tempoDeExecucao = getTimeExec(init, end);    
}

void analisaQuick(arquivo_t arquivo, analise_t *analise) {
    clock_t init, end;
    chave_t vetAux[arquivo.qtdeNum];
    
    for(int i=0; i<arquivo.qtdeNum; i++) vetAux[i] = arquivo.array[i];

    analise->algoritmoDeTeste = (char *)malloc(strlen("Quick Sort") * sizeof(char));
    strcpy(analise->algoritmoDeTeste,"Quick Sort");

    init = clock();
    quickSort(vetAux,0,arquivo.qtdeNum,&analise->numComparacoes,&analise->numExecucoes);
    end = clock();
    analise->tempoDeExecucao = getTimeExec(init, end);    
}

void gerarRelatorio(arquivo_t *arquivo, analise_t *analise) {
    char fileName[20];
    char str[200];
    char fileTitle[32];
    sprintf(fileName,"Relatorio_%d.txt",arquivo->qtdeNum);
    FILE *file = fopen(fileName,"w");

    if(!isNull(file)) {
        for(int i=0; i<QUANT_ARQUIVOS; i++) {
            sprintf(fileTitle,"ARQUIVO (ORD = 0%d | n = %d):\n", arquivo[i].tipoOrdenacao, arquivo[i].qtdeNum);
            fputs(fileTitle, file);
            for(int j=0; j<QUANT_ALGORITMOS; j++) {
                sprintf(str,"---------------\nAlgoritmo: %s\nNumComp: %d\nNumExec: %d\nTempo: %lf\n---------------\n",analise[j].algoritmoDeTeste,analise[j].numComparacoes, analise[j].numExecucoes, analise[j].tempoDeExecucao);
                fputs(str,file);
            }
        }
        
        fclose(file);
    } else {
        return;
    }
    
}

// -------------------------------------------------------------

void selectionSort(chave_t *vet, int n, int *numComp, int *numExec) {
    int i, j, menorNumero;
    chave_t x;

    for(i=0;i<=n;i++) {
        (*numComp)++;
        (*numExec)++;
        menorNumero = i;
        for(j = i; j <= n; j++) {
           if(vet[j] < vet[menorNumero])   menorNumero = j;
            (*numComp)++;       
        }
        x = vet[menorNumero];
        vet[menorNumero] = vet[i];
        vet[i] = x;
    }
}

void shellSort(chave_t *vet, int size, int *numComp, int *numExec) {
    int i , j;
    chave_t value;
    int gap = 1;
    while(gap < size) {
        (*numComp)++;
        gap = 3*gap+1;
    }
    (*numComp)++;
    while ( gap > 1) {
        (*numExec)++;
        gap /= 3;
        for(i = gap; i < size; i++) {
            (*numComp)++;            
            value = vet[i];
            j = i;
            while (j >= gap && value < vet[j - gap]) {
                vet[j] = vet[j - gap];
                j = j - gap;
            }
            vet[j] = value;
        }
    }
}

void insertionSort(chave_t vet[], int n, int *numComp, int *numExec) { 
   int i = 0, j = 1, aux;
   
    (*numComp)++;
    if(vet[j] < vet[i]) {
        TROCA(&vet[i], &vet[j]);
        (*numExec)++;
    }
    for(i=2; i<n; i++) {
        aux = i;
        (*numComp)++;
        for(j = i-1; j >= 0; j--) {
            (*numComp)++;
            if(vet[aux] < vet[j]) {
                TROCA(&vet[aux], &vet[j]);
                (*numExec)++;
            }
            aux--;
        }
    }
}

void quickSort(chave_t vet[], int esq, int dir, int *numComp, int *numExec){
    int i = esq;
    int j = dir;
    chave_t pivot;

    pivot = vet[(i + j)/2];
    while (i <= j){
        (*numComp)++;
        while (vet[i] < pivot && i < dir){
            i++;
            (*numComp)++;
        }
        (*numComp)++;
        while (pivot < vet[j] && j > esq){
            j--;
            (*numComp)++;
        }
        if (i <= j){
            (*numExec)++;
            TROCA(&vet[i],&vet[j]);
            i++;
            j--;
        }
    }

    if (j > esq)
        quickSort(vet, esq, j, numComp, numExec);
    if (i < dir)
        quickSort (vet, i, dir, numComp, numExec);
}

void ordenaDecrescente(chave_t *vet, int n) {
    int i, j, maiorNum;
    chave_t x;

    for(i=0; i<=n; i++) {
        maiorNum = i;
        for(j = i; j <= n; j++) {
           if(vet[j] > vet[maiorNum])   maiorNum = j;
        }
        x = vet[maiorNum];
        vet[maiorNum] = vet[i];
        vet[i] = x;
    }
}

// -------------------------------------------------------------

void setLocaleLang() {
 	setlocale(LC_ALL,"");
}

short int getOpSys() {
	#ifndef __LINUX__
		return LINUX_OS;
	#elif defined(__APPLE__)
		return MAC_OS;
	#elif defined(_WIN32) || defined(WIN32)
		return WINDOWS_OS;
	#else
		return NULL_OS;
	#endif
}

void clear() {
	switch(getOpSys()) {
        case LINUX_OS || MAC_OS:  system("clear"); break;
        case WINDOWS_OS:          system("cls");   break;
        default:                  exit(1);         break;
    }
}

void buffclear() {
	switch(getOpSys()) {
        case LINUX_OS || MAC_OS:  __fpurge(stdin); break;
        case WINDOWS_OS:          fflush(stdin);   break;
        default:                  exit(1);         break;
    }
}

void pausar(int tSeg) {
    #ifdef __unix__
        sleep(tSeg);
    #elif defined(_WIN32) || defined(WIN32)
        Sleep(tSeg*1000);
    #else
         exit(1);
    #endif
}

void alert(const char *str, int color, int tSecPause) {
    if(color == GREEN)  printf(ANSI_COLOR_GREEN "\n[*] %s" ANSI_COLOR_RESET, str);
    else if(color == RED)   printf(ANSI_COLOR_RED "\n[!] %s" ANSI_COLOR_RESET, str);
    else    return;
    if(tSecPause == 0)
        return;
    pausar(tSecPause);
}

int numrand(int vInicial, int vFinal) {
	return (vInicial + (rand() % (vFinal - vInicial)));
}

double getTimeExec(clock_t init, clock_t end) {
    //return ((double)(end - init) / CLOCKS_PER_SEC);
    return ((double)(end - init) * 1000.0 / CLOCKS_PER_SEC);
}