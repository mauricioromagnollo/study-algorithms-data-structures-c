#include "analyzer.h"

short int getMenu() {
    short int op;
    printf("\n--------------------\n");
    printf("1 - Construir Arquivos\n");
    printf("2 - Realizar Análise\n");
    printf("3 - Sair\n");
    printf("--------------------\n");
    scanf("%hi", &op);
    return(op);
}

void setLocaleLang() {
    setlocale(LC_ALL,"");
}

short int getOpSys() {
    #ifndef __LINUX__
	    return LINUX_OS;
    #elif defined(__APPLE__)
	    return MAC_OS;
    #elif defined(_WIN32) || defined(WIN32)
	    return WINDOWS_OS;
    #else 
	    return NULL_OS;
    #endif
}

void clear() {
    switch(getOpSys()) {
        case LINUX_OS || MAC_OS:  system("clear"); break;
        case WINDOWS_OS:          system("cls");   break;
        default:                  exit(1);         break;
    }
}

void buffclear() {
    switch(getOpSys()) {
        case LINUX_OS || MAC_OS:  __fpurge(stdin); break;
        case WINDOWS_OS:          fflush(stdin);   break;
        default:                  exit(1);         break;
    }
}

void alert(const char *str, int color, int tSecPause) {
    if(color == GREEN)  printf(ANSI_COLOR_GREEN "\n[*] %s" ANSI_COLOR_RESET, str);
    else if(color == RED)   printf(ANSI_COLOR_RED "\n[!] %s" ANSI_COLOR_RESET, str);
    else    return;
    if(tSecPause == 0)
        return;
    pausar(tSecPause);
}

int numrand(int vInicial, int vFinal) {
    return (vInicial + (rand() % (vFinal - vInicial)));
}

void pauseScript(int tSeg) {
    #ifdef __unix__
        sleep(tSeg);
    #elif defined(_WIN32) || defined(WIN32)
        Sleep(tSeg*1000);
    #else
        exit(1);
    #endif
}

bool isNumber(char *str) {
    for(short int i = 0; i < strlen(str); i++) {
        if(!isdigit(str[i]))    
            return false;
    }
    return true;    
}

int parseStrToInt(char *str) {
    if(isNumber(str))
        return atoi(str);
    else
        return INT_ERROR;
}