#!/bin/bash
chmod +x execute.sh

pathToBack=$(pwd)

cd src/
gcc -o executavel analyzer.h analyzer.c main.c -lm
./executavel
rm executavel
cd $pathToBack

unset pathToBack