#ifndef ANALYZER_H_INCLUDED
#define ANALYZER_H_INCLUDED

/** Incluindo outras libs */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <ctype.h>

#ifdef __unix__
    #include <unistd.h>
#elif defined(_WIN32) || defined(WIN32)
    #include <windows.h>
#endif

/** Definindo Dados Auxiliares */
enum { NULL_OS, LINUX_OS, WINDOWS_OS, MAC_OS };
enum { RED, GREEN };
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_RESET   "\x1b[0m"

/** Definindo Estruturas de Dados */
typedef enum { false, true } bool;
typedef int chave_t;

typedef struct {
    char *nome;
    short int tipoOrdenacao;
    int length;
    chave_t *array;
}arquivo_t;

typedef struct {
    char *algoritmoDeTeste;
    int numComparacoes;
    int numExecucoes;
    double tempoDeExecucao;
}analisador_t;

/** Constantes do Menu */
#define CRIAR_ARQUIVO 1
#define FAZER_ANALISE 2
#define SAIR_DO_PROGRAMA 3

/** Define Tipo Arquivo */
#define QUANT_ARQUIVOS 3
#define QUANT_ALGORITMOS 4
#define DELIMITADOR ','
#define ARQUIVO_EXTENSAO ".dat"
#define ARQUIVO_PADRAO_ESCRITA "0%d_%d.dat"

#define INT_ERROR (__INT_MAX__ * -1)

enum { VAZIO, CRESCENTE, DECRESCENTE, RANDOM };

/** Método Auxiliar Para Troca de Valores */
#define TROCA(a,b) \
    chave_t tmp;   \
    tmp = *a;      \
    *a = *b;       \
    *b = tmp;      \

/** Interface analyzer */
short int getMenu();


/** Funções auxiliares */
void setLocaleLang();
short int getOpSys();
void clear();
void buffclear();
void alert(const char *str, int color, int tSecPause);
int numrand(int vInicial, int vFinal);
void pauseScript(int tSeg);
bool isNumber(char *str);
int parseStrToInt(char *str);

#endif // ANALYZER_H_INCLUDED