
#include "analyzer.h"

int main() {
  
  FILE *file;
  arquivo_t arquivo[QUANT_ARQUIVOS];
  analisador_t analisador[QUANT_ALGORITMOS * QUANT_ARQUIVOS];
  bool sairDoPrograma = false;
  bool arquivosCriados = false;

  while(!sairDoPrograma) {
    clear();
    switch(getMenu()) {

      case CRIAR_ARQUIVO:
        // ...
        break;
    
      case FAZER_ANALISE:
        // ...
        break;

      case SAIR_DO_PROGRAMA:
        alert("[!] Finalizando o programa!\n", RED, 2);
        sairDoPrograma = true;
        break;
      
      default:
        alert("[!] Opção inválida!\n", RED, 2);
        sairDoPrograma = false;    
        break;
    
    }
  }

  return 0;
}