				/* BATALHA NAVAL */	// batalha_naval.h
/*
* CSI030-2018-01 - Programacao de Computadores I
* Nome........: Maurício Romagnoli Silveira
* Matricula...: 16.2.8315
* Curso.......: Engenharia de Computação (UFOP - ICEA, JM)
* Exercicio...: Batalha-Naval / atividade pratica 02
*/

#include <stdio.h>
#include <stdlib.h>

#ifndef BATALHA_NAVAL_H
#define BATALHA_NAVAL_H 

/* Constantes */
#define ON 1
#define OFF 0
#define TABSIZE 15
#define PLAYERSMAX 2
#define ROUNDMAX 6
#define SUBMARINO 'x'
#define PORTAAVIAO 'y'

/* Estrutura de dados do jogador */
struct jogador
{
	char nome[30];
	int pontos;
	char tabuleiro[TABSIZE+1][TABSIZE+1];
	short int machine;
};

/*
** Limpa a tela do terminal
*/
void clear();
/*
** Configura caracteres especiais
*/
void utf8();
/*
** Limpa lixo de memoria
*/
void limpar_buffer();
/*
** Pausa a execucao do codigo por __segundos
*/
void pause_script(short int __segundos);
/*
** Retorna um numero aleatorio entre __init e __end
** Os parametros sao (valorInicial,ValorFinal)
** ex: var = numrand(0,10);
** var recebe um numero entre 0 e 10
*/
short int numrand(short int __init, short int __end);
/*
** Retorna indice do vencedor a partir dos pontos
** Retorna -1 no caso de empate
*/
short int indice_vencedor(struct jogador *player);
/*
** Atribui jogada para o jogador 0 quando o round e par
** caso o round seja impar, quem joga e o jogador 1
** rounds: 0,2,4 (jogador 0)
** 		   1,3,5 (jogador 1)
*/
void verifica_quem_joga(short int numround, short int *i, short int *adversario);
/*
** 
*/
void recebe_nome(char *str, short int n);
/*
** Recebe um numero entre 50 e 100
** assegura que seja um numero par
** retorna 20% do numero para PORTAAVIAO
** retorna 80% do numero para SUBMARINO
*/
void gerar_embarcacoes(short int *numPortaAvioes, short int *numSubmarinos);
/*
** Cria um tabuleiro 15x16 preenchendo com ' '
*/
void cria_tabuleiro_vazio(char tab[TABSIZE][TABSIZE+1]);
/*
** adiciona 'y' porta avioes e 'x' submarinos na matriz do jogador
*/
void preencher(char tab[TABSIZE][TABSIZE+1], short int y, short int x);
/*
**
*/
void recebe_disparo(short int *i, short int *j);
/*
**
*/
int valor_disparo(char tab[TABSIZE][TABSIZE+1], short int linha, short int coluna);
/*
**
*/
short int erro_entrada(short int num, short int valorEntrada);
/*
** Retorna o valor da opcao de menu
** Possui menu de inicio do jogo e novo jogo
*/
short int Menu(char const *str);
/*
** Raliza uma jogada para o player "maquina"
** Possui menu de inicio do jogo e novo jogo
*/
void machineplay(char tab[TABSIZE][TABSIZE + 1], short int *linha, short int *coluna);
/*
**
*/
void imprime(char const *str);
/*
**
*/
void exibe(char tab[TABSIZE][TABSIZE + 1], char const *str);
/*
**
*/
void result(struct jogador *player, short int indiceVencedor);
/*
** Exibe mensagem e finaliza o jogo!
*/
short int end_game();

// Fim
#endif