				/* BATALHA NAVAL */	// main.c
/*
* CSI030-2018-01 - Programacao de Computadores I
* Nome........: Maurício Romagnoli Silveira
* Matricula...: 16.2.8315
* Curso.......: Engenharia de Computação (UFOP - ICEA, JM)
* Exercicio...: Batalha-Naval / atividade pratica 02
*/

/* Bibliotecas */
#include <stdio.h>
#include <stdlib.h>
#include "batalha_naval.h"

/* Estrutura de dados */
typedef struct jogador JOGADOR;

/* Assinatura */
void Batalha_Naval();
void teste();

/* Funcao Principal */
// ----------------------------------
int main(int argc, char const *argv[])
{
	clear();
	limpar_buffer();
	utf8();
	
	Batalha_Naval();
//	teste();
	return 0;
}
// ----------------------------------

void teste() {
	clear();
	printf("[*] Função de teste!\n");
	pause_script(1);
}

void Batalha_Naval() {

	JOGADOR player[PLAYERSMAX];
	short int nX, nY;	// nX = numero de Submarinos, nY = n. de porta-avioes
	short int i, j;
	short int newGame = ON, round;
	short int iPlayer, iAdversario, iVencedor; // iPlayer = Jogador que ira efetuar a jogada
	int pontosDisparo;

	// Condicao Novo Jogo
	while(newGame == ON)
	{
		clear();
		limpar_buffer();
		imprime("titulo");
		newGame = Menu("inicio");			

		// fecha o game
		if(newGame == 0) {
			newGame = end_game();

		// Inicia Game		
		} else {

			/* Criar: Jogadores e Tabuleiros */
			
			player[0].machine = OFF;
			player[1].machine = OFF;
			if(newGame == 1) {	
				player[1].machine = ON;
			}

			gerar_embarcacoes(&nX,&nY);

			for(i = 0; i < PLAYERSMAX; i++)
			{
				player[i].pontos = 0;

				if(player[i].machine == ON) {
					strcpy(player[i].nome, "Player Machine");
				} else {
					recebe_nome(player[i].nome, i);
				}

				limpar_buffer();
				cria_tabuleiro_vazio(player[i].tabuleiro);
				preencher(player[i].tabuleiro,nY,nX);	
			}

			/* Iniciar Rodadas */
			
			round = 0;
			while(round < ROUNDMAX)
			{
				verifica_quem_joga(round,&iPlayer,&iAdversario);

				clear();
				imprime("titulo");
				printf("[*] Tabuleiro do jogador \"%s\":\n",player[iAdversario].nome);
				exibe(player[iAdversario].tabuleiro,"hide");

				printf("\n[*] Vez do jogador \"%s\".\n",player[iPlayer].nome);
				printf("[*] Pontuação: %d pontos.\n",player[iPlayer].pontos);

				if(player[iPlayer].machine == ON) {
					machineplay(player[iAdversario].tabuleiro,&i,&j);
				} else {
					recebe_disparo(&i,&j);
				}

				player[iPlayer].pontos += valor_disparo(player[iAdversario].tabuleiro,i,j);				
				pause_script(2);

				clear();
				imprime("titulo");
				printf("[*] Exibindo tabuleiro do jogador %s\n",player[iAdversario].nome);
				exibe(player[iAdversario].tabuleiro,"hide");
				pause_script(2);
				round++;
			} // Fim Loop de Rodadas

			/* Retorna Resultados */
			iVencedor = indice_vencedor(player);
		
			clear();
			imprime("titulo");
			result(player,iVencedor);

			/* Menu para Iniciar novo jogo ou Finalizar */

			newGame = Menu("novojogo");
			if(newGame == 0) {
				newGame = end_game();
			} else {
				newGame = ON;
			}
		} // Fim else Inicia Game
	} // Fim  Loop Condicao Novo Jogo
}