				/* BATALHA NAVAL */	// batalha_naval.c
/*
* CSI030-2018-01 - Programacao de Computadores I
* Nome........: Maurício Romagnoli Silveira
* Matricula...: 16.2.8315
* Curso.......: Engenharia de Computação (UFOP - ICEA, JM)
* Exercicio...: Batalha-Naval / atividade pratica 02
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <time.h>
#include "batalha_naval.h"

void clear() {
	#ifdef __unix__
		system("clear");
	#elif defined(_WIN32) || defined(WIN32)
		system("cls");
	#else
		printf("[!] Erro: void clear()\n");
	#endif
}

void utf8() {
	setlocale(LC_ALL,"");
}

void limpar_buffer() {
    #ifdef __unix__
        __fpurge(stdin);
    #elif defined(_WIN32) || defined(WIN32)
        fflush(stdin);
    #else
        printf("\t[!] Erro: void limpar_buffer()\n");
    #endif
}

void pause_script(short int __segundos) {
	char esperar[20];
	short int __err=0;
	#ifdef __unix__
		sprintf(esperar, "sleep %hi",__segundos);
	#elif defined(_WIN32) || defined(WIN32)
		sprintf(esperar, "WAITFOR /T %hi",__segundos);
	#else
		__err = 1;
		printf("\t[!] Erro: void esperar()!\n");
	#endif

	if(__err == 0)
		system(esperar);
}

short int numrand(short int __init, short int __end) {
//	srand(time(NULL));
	return (__init + (rand() % (__end- __init))); 
}
short int indice_vencedor(struct jogador *player) {
	if(player[0].pontos > player[1].pontos) return 0;
	else if(player[0].pontos < player[1].pontos) return 1;
	else return -1;
}

void verifica_quem_joga(short int numround, short int *i, short int *adversario) {
	if(numround % 2 == 0) {
		*i = 0;
		*adversario = 1;
	} else {
		*i = 1;
		*adversario = 0;
	}
}

void recebe_nome(char *str, short int n) {
	printf("[*] Nome do %hiº player:\n> ",(n+1));
	limpar_buffer();
	scanf("%[^\n]s",str);
}

void cria_tabuleiro_vazio(char tab[TABSIZE][TABSIZE+1]) {
	for (int i = 0; i < (TABSIZE); ++i)
	{
		for (int j = 0; j < (TABSIZE+1); ++j)
		{
			tab[i][j] = ' ';
		}
	}
}

void gerar_embarcacoes(short int *numPortaAvioes, short int *numSubmarinos) {
	short int n;
	n = numrand(50,100);
	if(n % 2 != 0) {
		n += 1;
	}

	*numPortaAvioes = (n * 0.20);
	*numSubmarinos = (n * 0.80);
}

void preencher(char tab[TABSIZE][TABSIZE+1], short int y, short int x) {
	short int i,j;

	while(y != 0) 
	{
		i = numrand(0,TABSIZE-1);
		j = numrand(0,TABSIZE-1);

		if(tab[i][j-1] != 'y' && tab[i][j] == ' ' && tab[i][j+1] == ' ' && tab[i][j+1] != '\0') {
			tab[i][j] = PORTAAVIAO;
			tab[i][j+1] = PORTAAVIAO;
			y--;
		} else {
			i = numrand(0,TABSIZE-1);
			j = numrand(0,TABSIZE-1);
		}
	}

	while(x != 0) 
	{
		i = numrand(0,TABSIZE-1);
		j = numrand(0,TABSIZE-1);

		if(tab[i][j] == ' ') {
			tab[i][j] = SUBMARINO;
			x--;
		} else {
			i = numrand(0,TABSIZE-1);
			j = numrand(0,TABSIZE-1);
		}
	}		
}

void recebe_disparo(short int *i, short int *j) {
  	printf("------------------------------------\n");
	printf("[*] Digite a posição do disparo:\n");
	printf("------------------------------------\n");
	*i = TABSIZE+1;
	*j = TABSIZE+1;

	printf("[ ] Linha: ");
	while(*i < 1 || *i > TABSIZE) {
		limpar_buffer();
		scanf("%hi", &*i);
	}

	printf("[ ] Coluna: ");
	while(*j < 1 || *j > TABSIZE) {
		limpar_buffer();
		scanf("%hi", &*j);
	}

	*i -= 1;
	*j -= 1;
}

int valor_disparo(char tab[TABSIZE][TABSIZE+1], short int linha, short int coluna)
{
	if(tab[linha][coluna] == SUBMARINO) {
		tab[linha][coluna] = '*';
		printf("[*] Você acertou um submarino! (+100 pontos)\n");
		return 100;		
	} else if(tab[linha][coluna] == PORTAAVIAO) {
		tab[linha][coluna] = '*';
		if(tab[linha][coluna+1] == PORTAAVIAO) {
			tab[linha][coluna+1] = '*';
		} else if(tab[linha][coluna-1] == PORTAAVIAO) {
			tab[linha][coluna-1] = '*';
		}			
		printf("[*] Você acertou um porta-avião! (+200 pontos)\n");
		return 200;		
	} else {
		tab[linha][coluna] = '~';
		printf("[!] Você errou o disparo!\n");
		return 0;		
	}
}

short int erro_entrada(short int num, short int valorEntrada) {
	if(num == 1) {
		if(valorEntrada < 0 || valorEntrada > 2)
			return 1;
	} else if(num == 2) {
		if(valorEntrada < 0 || valorEntrada > 1)
			return 1;
	} else {
		return 0;
	}
}

void machineplay(char tab[TABSIZE][TABSIZE + 1], short int *linha, short int *coluna)
{
	short int i,j;
	i = numrand(1,TABSIZE);
	j = numrand(1,TABSIZE);

	while(tab[i][j] != ' ' || tab[i][j] == '*' || tab[i][j] == '~')
	{
		i = numrand(0,TABSIZE);
		j = numrand(0,TABSIZE);
	}

	*linha = i;
	*coluna = j;
	pause_script(1);
	printf("[ ] Linha: %i\n",i);
	pause_script(1);
	printf("[ ] Coluna: %i\n",j);
	pause_script(1);
}

void imprime(char const *str) {
	if(strcmp(str,"titulo") == 0) {
		printf("\n");
		printf("\t\t -------------------------\n");
		printf("\t\t | *** BATALHA-NAVAL *** |\n");
		printf("\t\t -------------------------\n");
	
	} else if(strcmp(str,"erroEntrada") == 0) {
		printf("[!] Opção inválida!\n[*] Digite novamente...");
	
	} else if(strcmp(str,"erroEscala") == 0) {		
		printf("[!] Erro! Fora de escala do tabuleiro.\n[*] Digite novamente...");
	} else if(strcmp(str,"exit") == 0) {
		printf("[*] Saindo do programa...\n");
	}
}

void exibe(char tab[TABSIZE][TABSIZE + 1], char const *str) {
	char espaco = ' ';
	for(int i = 0; i < (TABSIZE+1); i++) {
		for(int j = 0; j < (TABSIZE+1); j++) {
			printf("[");
			if(i == 0) {
				if(j > 9) {
					printf("%d ",j);
				} else {
					printf(" %d ",j);
				}
			} else if(j == 0) {
				if(i > 9) {
					printf("%d ",i);
				}
				else {
					printf(" %d ",i);
				}
			} else if(i == 0 && j == 0) {
				printf("0");
			} else {
				// Se tipoExib == 0, exibe o tabuleiro durante o jogo
				if(strcmp(str,"hide") == 0) {
					if(tab[i-1][j-1] == 'x' || tab[i-1][j-1] == 'y') {
						printf(" %c ",espaco);
					} else {
						printf(" %c ",tab[i-1][j-1]);				
					}	
				// Se nao, se tipoExib == 1, exibe o tab final
				} else if(strcmp(str,"end") == 0) {
					printf(" %c ",tab[i-1][j-1]);	
				}
			}
			printf("]");			
		}
		printf("\n");
	}
}

void result(struct jogador *player, short int indiceVencedor) {
	printf("***********************************\n");
	printf("[**] Resultado do Game:\n");
	printf("[P1] %s:.... %d pontos\n", player[0].nome,player[0].pontos);
	printf("[P2] %s:.... %d pontos\n", player[1].nome,player[1].pontos);
	if(indiceVencedor == -1) {
		printf("[*] Empate! Os dois jogadores fizeram %d pontos!\n", player[0].pontos);
	} else {
		printf("[*] Vencedor:... %s com %d pontos.\n",player[indiceVencedor].nome, player[indiceVencedor].pontos);
	}
	printf("***********************************\n");		

	pause_script(5);

	printf("\n[*] Tabuleiro do jogador %s\n",player[0].nome);
	exibe(player[0].tabuleiro,"end");
	printf("\n");
	pause_script(1);

	printf("[*] Tabuleiro do jogador %s\n",player[1].nome);
	exibe(player[1].tabuleiro,"end");
	pause_script(1);
}

short int end_game() {
	printf("[*] Finalizando o game...\n");
	pause_script(2);
	clear();
	exit(0);
	return 0;
}

short int Menu(char const *str) {
	short int op;

	if(strcmp(str,"inicio") == 0) {
		printf("========================\n");
		printf("1 - ONE PLAYER\n");
		printf("2 - TWO PLAYERS\n");
		printf("0 - EXIT\n");
		printf("========================\n");
		printf("> ");
		op = -1;
		while(op < 0 || op > 2) {
			limpar_buffer();
			scanf("%hi",&op);
		}

	} else if(strcmp(str,"novojogo") == 0) {
		printf("========================\n");
		printf("1 - NEW GAME\n");
		printf("0 - EXIT\n");
		printf("========================\n");
		printf("> ");
		op = -1;
		while(op < 0 || op > 1) {
			limpar_buffer();
			scanf("%hi",&op);
		}
	}

	return op;	
}