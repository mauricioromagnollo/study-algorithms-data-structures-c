#!/bin/bash	--utf8
# exec.sh
# ---------------------------
# Exec. arquivos em C
# Maurício Romagnoli (x0n4d0)
# ---------------------------
chmod a+x exec.sh
clear
gcc -c *.c
gcc -o exe *.o
./exe
rm *.o; rm exe